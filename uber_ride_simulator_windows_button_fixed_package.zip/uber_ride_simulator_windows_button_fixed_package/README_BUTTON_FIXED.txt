UBER RIDE SIMULATOR - WINDOWS BUTTON FIX

The Select UberX / UberXL / Uber Black / Uber Pool buttons are now kept
inside a permanent action row, so Windows display scaling cannot hide them.

HOW TO RUN
1. Extract the ZIP.
2. Keep both files in the same folder.
3. Double-click RUN_UBER_BUTTON_FIXED.bat

Alternative Command Prompt command:
   py -3 uber_ride_simulator_windows_button_fixed.py
