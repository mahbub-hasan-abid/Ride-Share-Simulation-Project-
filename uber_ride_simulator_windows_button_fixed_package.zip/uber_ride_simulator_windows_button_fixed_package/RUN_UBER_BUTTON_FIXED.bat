@echo off
setlocal
cd /d "%~dp0"
title Uber Ride Simulator Launcher

echo ==========================================
echo   Uber Ride Simulator - Button Fixed
echo ==========================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    py -3 -c "import tkinter" >nul 2>&1
    if errorlevel 1 goto tkinter_missing_py
    py -3 "uber_ride_simulator_windows_button_fixed.py"
    if errorlevel 1 goto app_error
    goto finished
)

where python >nul 2>&1
if %errorlevel%==0 (
    python -c "import tkinter" >nul 2>&1
    if errorlevel 1 goto tkinter_missing_python
    python "uber_ride_simulator_windows_button_fixed.py"
    if errorlevel 1 goto app_error
    goto finished
)

echo Python was not found on this laptop.
echo Install Python 3 from python.org and tick:
echo     Add python.exe to PATH
echo Then run this file again.
echo.
pause
exit /b 1

:tkinter_missing_py
echo Tkinter is missing from the current Python installation.
echo Reinstall Python from python.org and include "tcl/tk and IDLE".
echo.
pause
exit /b 1

:tkinter_missing_python
echo Tkinter is missing from the current Python installation.
echo Reinstall Python from python.org and include "tcl/tk and IDLE".
echo.
pause
exit /b 1

:app_error
echo.
echo The app stopped because of an error.
echo Open uber_error.log in this folder to see the exact reason.
echo.
pause
exit /b 1

:finished
exit /b 0
